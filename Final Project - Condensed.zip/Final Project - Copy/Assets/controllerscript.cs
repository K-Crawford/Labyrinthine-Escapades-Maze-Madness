﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controllerscript : MonoBehaviour
{
    public GameObject Snail;
    public bool isFiring;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.rotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.RTrackedRemote);

        if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger) && isFiring)
        {
            Instantiate(Snail, this.transform.position, this.transform.rotation);
            isFiring = false;
        }
        if (OVRInput.GetUp(OVRInput.Button.PrimaryIndexTrigger) && !isFiring)
        {
            isFiring = true;
        }
        
    }
}
