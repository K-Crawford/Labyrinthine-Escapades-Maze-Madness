﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class playercontroller : MonoBehaviour
{
    public GameObject cameraCenter;
    public Vector2 touchpad;
    private float horizInput;
    private float vertInput;
    public CharacterController characterController;
    public int speed;
    public GameObject ovr;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.eulerAngles = new Vector3(0, cameraCenter.transform.localEulerAngles.y, 0);
        touchpad = OVRInput.Get(OVRInput.Axis2D.PrimaryTouchpad);
        horizInput = Input.GetAxis("Horizontal");
        vertInput = Input.GetAxis("Vertical");
        Vector3 position = new Vector3(transform.position.x, transform.position.y + 0.5f, transform.position.z);
        ovr.transform.position = Vector3.Lerp(ovr.transform.position, position, 28f * Time.deltaTime);

        Vector3 ForwardMovement = transform.forward * touchpad.y * speed;
        Vector3 RightMovement = transform.right * touchpad.x * speed;
        characterController.SimpleMove(ForwardMovement + RightMovement);
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            GameObject.Find("Game Manager").GetComponent<gamemanager>().coins++;
            Destroy(other.gameObject);
        }
        if (other.gameObject.CompareTag("Enemy"))
        {
          
        }

    }
    
}

